package login;

public class Contact {
	private String m_username;
	
	
	
	public Contact(String m_username) {
		this.m_username = m_username;
	}
	
	// GETTERS
	public String getM_username() {
		return m_username;
	}
	
	// SETTERS
	public void setM_username(String m_username) {
		this.m_username = m_username;
	}
	
	
}