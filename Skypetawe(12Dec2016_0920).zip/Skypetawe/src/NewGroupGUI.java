import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.LinkedList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import filereader.AccountReader;
import filereader.ContactsReader;
import filereader.RoomReader;
import login.Account;
import login.Contact;

import java.awt.Color;
import java.awt.Component;
import javax.swing.SwingConstants;

/**
 * SearchGUI.java
 * @author Yiu Ting Lai
 * @author Osian Smith 
 * @author Ahmed Elmi
 */

public class NewGroupGUI {
	
	
	
	/**
	 * Launch the application.
	 */
	/*
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					//NewGroupGUI window = new NewGroupGUI();
					//window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	*/

	/**
	 * Create the application.
	 */
	public NewGroupGUI(HomeGUI parent) {
		m_parent = parent;
		
		initialize();
		
	}

	/**
	 * Initialize the contents of the frame.
	 * @wbp.parser.entryPoint
	 */
	private void initialize() {
		m_frame = new JFrame();
		m_frame.setBounds(100, 100, 500, 400);
		m_frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		m_frame.getContentPane().setLayout(null);
		
		initializeData();
		initializeMainGUI();
	    
	    m_frame.setVisible(true);
	}
	
	/**
	 * Get the values which enables to make a new group chat
	 */
	private void initializeData() {
		m_users = new String[Group9application.getM_cl().size()];
		
		for(int i = 0; i < m_users.length; i++) {
			m_users[i] = ((Contact)Group9application.getM_cl().get(i)).getM_username();
		}
		
	}
	
	/**
	 * Initalise the contents of the JFrame
	 */
	private void initializeMainGUI() {
		txtSearch = new JTextField();
		txtSearch.setBounds(5, 6, 200, 30);
		txtSearch.setColumns(10);
		
		String txt = txtSearch.getText();
		
		m_searchAction = new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				search();
				
			}
		};
		
		btnSearch = new JButton("Search");
		btnSearch.setBounds(225, 7, 75, 29);
		btnSearch.addActionListener(m_searchAction);
		
		
		
		m_lblEngagedUsers = new JLabel();
		m_lblEngagedUsers.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		m_lblEngagedUsers.setVerticalAlignment(SwingConstants.TOP);
		m_lblEngagedUsers.setBounds(222, 47, 251, 233);
		
		
		
		//creates canncel button
		this.m_btnWhiteboard = new JButton("WhiteBoard");
		
		m_WhiteboardAction = new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				Whiteboard();
				
			}
		};
		
		m_btnWhiteboard.addActionListener(m_WhiteboardAction);
		this.m_btnWhiteboard.setBounds(405, 285, 90, 45);
		this.m_btnWhiteboard.setEnabled(true);
		
		
		m_addMouse = new MouseAdapter() {
			public void mouseClicked(MouseEvent mouseEvent) {
				JList theList = (JList) mouseEvent.getSource();
				int index = theList.locationToIndex(mouseEvent.getPoint());
				Object o = theList.getModel().getElementAt(index);
				if (mouseEvent.getClickCount() == 2) {
					if (index >= 0) {
						// Call to add for adding an engaged user
						addUser(m_users[index]);
						
					}
				}
				
			}
		};
		
		m_usersList = new JList(m_users);
		m_usersList.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		m_usersList.addMouseListener(m_addMouse);
		m_usersPane = new JScrollPane(m_usersList);
		m_usersPane.setBounds(5, 40, 200, 290);
		
		
		m_frame.getContentPane().add(txtSearch);
		m_frame.getContentPane().add(btnSearch);
		m_frame.getContentPane().add(m_usersPane);
		m_frame.getContentPane().add(m_lblEngagedUsers);
		m_frame.getContentPane().add(m_btnWhiteboard);
		
		m_sendMsgAction = new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				sendMsg();
			}
		};
		
		m_btnSendMsg = new JButton("Send");
		m_btnSendMsg.setBounds(405, 330, 90, 45);
		m_btnSendMsg.addActionListener(m_sendMsgAction);
		
		m_frame.getContentPane().add(m_btnSendMsg);
		
		m_AddAction = new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				addUser(m_users[m_usersList.getSelectedIndex()]);
				m_lblEngagedUsers.setText(m_lblEngagedUsers.getText() + " " + m_users[m_usersList.getSelectedIndex()]);
			}
		};
		m_btnAdd = new JButton("Add");
		m_btnAdd.setBounds(5, 340, 80, 30);
		m_btnAdd.addActionListener(m_AddAction);
		
		m_frame.getContentPane().add(m_btnAdd);
		m_frame.setVisible(true);
		
	}
	
	/**
	 * 
	 */
	public boolean search() {
		String keyword = txtSearch.getText();
		System.out.println("Search");
		// Call to AccountReader
		LinkedList<String> users;
		try{
			
		}catch(Exception e) {
			System.out.println("SearchGUI: search Exception");
			users = new LinkedList<String>();
		}
		
		m_usersList.setListData(m_users);
		
		return true;
	}
	
	/**
	 * Send a message to a group chat
	 */
	public void sendMsg() {
		System.out.println("SendMSG");
		
		String roomname = "";
		
		//Call to ChatGUI for send message
		roomname = Group9application.chkRoomExist(m_group);
		
		final String rn = roomname;
		
		if(rn.equals("")) {
			System.out.println("Roomname: " + roomname);
			try {
				int totalRoomNum = new RoomReader().getRooms().size();
				new RoomReader().newRoom("room" + (totalRoomNum + 1), "c");
				
				for(int i=0; i<m_group.size(); i++) {
					new RoomReader().newRoomMember("room" + (totalRoomNum + 1), m_group.get(i));
				}
				
				final String rn_new = "room" + (totalRoomNum + 1);
				
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							//LoginGUI window = new LoginGUI();
							ChatGUI window = new ChatGUI(rn_new);
							window.displayGUI();
							//window.frame.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
				
			}catch(Exception e) {
				System.out.println(e);
			}
			
		}else {
			System.out.println("Roomname: " + roomname);
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						//LoginGUI window = new LoginGUI();
						ChatGUI window = new ChatGUI(rn);
						window.displayGUI();
						//window.frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		}
		m_parent.refreshGUI();
		m_frame.dispose();
		
	}
	
	/**
	 * Initialise the creative drawing environment
	 */
	public void Whiteboard() {
		System.out.println("Whiteboard");
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					//LoginGUI window = new LoginGUI();
					CDE window = new CDE();
					//window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		m_parent.refreshGUI();
		m_frame.dispose();
		
	}
	
	/**
	 * Add a contact to the group chat
	 * @param user the username of the contact being added
	 */
	public void addUser(String user){
		System.out.println("Add: "+user);
		if(m_group.size() == 0) {
			System.out.println("Add0: "+user);
			m_group.add(user);
			m_lblEngagedUsers.setText(user);
		}
		
		boolean temp = true;
		for(int i=0; i<m_group.size(); i++) {
			if(user.equals(m_group.get(i))) {
				temp = false;
			}
			
		}
		if(temp) {
			m_group.add(user);
			m_lblEngagedUsers.setText(m_lblEngagedUsers.getText() + " " + user);
			m_frame.setVisible(true);
		}
		
	}
	private JFrame m_frame;
	private JTextField txtSearch;
	private JButton btnSearch;
	private JScrollPane m_usersPane;
	private JList m_usersList;
	private JLabel m_lblEngagedUsers;
	private JButton m_btnWhiteboard;
	private MouseAdapter m_addMouse;
	private ActionListener m_searchAction;
	private ActionListener m_WhiteboardAction;
	private ActionListener m_sendMsgAction;
	private ActionListener m_AddAction;
	
	
	private HomeGUI m_parent;
	
	private String m_account;
	private String[] m_users;
	private JButton m_btnSendMsg;
	private JButton m_btnAdd;
	
	private LinkedList<String> m_group = new LinkedList<String>();
}