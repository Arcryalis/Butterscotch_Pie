
/**
 * CDE.java
 * @author Sevan Boyrazian, Rhydian Morgan, Ahmed Elmi
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.LayoutStyle.ComponentPlacement;

import draw.DrawElement;
import draw.StraightLine;
import draw.ParticleTrace;

import java.awt.SystemColor;
import java.awt.Font;


/**
 * CDE class is the GUI for the collaborative drawing environment.
 */

public class CDE extends JFrame implements ActionListener {

	
	/**
	 * Main method for testing the collaborative drawing environment from inside the class directly.
	 */
	/*
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CDE window = new CDE();
					// window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * The constructor that creates an instance of the collaborative drawing environment.
	 */
	public CDE() {
		/**
		 * The JFrame which contains all of the components of the CDE GUI
		 */
		JFrame frame = new JFrame("Collaborative Drawing Environment");
		frame.setFont(new Font("Lucida Grande", Font.BOLD, 14));
		frame.getContentPane().setBackground(Color.ORANGE);
		frame.setVisible(true);
		frame.setSize(451, 300);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		JMenuBar menuBar = new JMenuBar();
		menuBar.setForeground(Color.BLACK);
		menuBar.setBackground(Color.DARK_GRAY);
		frame.setJMenuBar(menuBar);

		/**
		 * The JMenu button File which when clicked presents "Save" and "Exit"
		 */
		JMenu mnFile = new JMenu("File");
		mnFile.setBackground(SystemColor.textHighlight);
		menuBar.add(mnFile);
		
		/**
		 * The "Save" button which can be found when the File JMenu button is
		 * clicked. It saves what is drawn in the collaborative drawing
		 * environment.
		 */
		JMenuItem mntmSave = new JMenuItem("Save");
		mntmSave.setBackground(SystemColor.textHighlight);
		mntmSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BufferedImage image = new BufferedImage(m_panel.getWidth(), m_panel.getHeight(), BufferedImage.TYPE_INT_RGB);
				Graphics2D g = image.createGraphics();
				m_panel.printAll(g);
				g.dispose();
				try {
					ImageIO.write(image, "jpg", new File("Paint.jpg"));
					ImageIO.write(image, "png", new File("Paint.png"));
				} catch (IOException exp) {
					exp.printStackTrace();
				}
				getContentPane().add(m_panel, BorderLayout.SOUTH);
			}
		});
		mnFile.add(mntmSave);

		/**
		 * The "Exit" button which can be found when the File JMenu button is
		 * clicked. It exits the collaborative drawing environment.
		 */
		JMenuItem mntmExit = new JMenuItem("Exit");
		mntmExit.setBackground(SystemColor.textHighlight);
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		mnFile.add(mntmExit);
		frame.getContentPane().setLayout(null);

		/**
		 * The "Particle" button which can be found in the CDE GUI which allows
		 * the user to draw particles in the drawing area.
		 */
		JButton button = new JButton("Particle");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				m_particles.setVisible(true);
				m_line.setVisible(false);
			}
		});
		button.setBounds(84, 18, 117, 29);
		frame.getContentPane().add(button);

		/**
		 * The "Straight Line" button which can be found in the CDE GUI which
		 * allows the user to draw straight lines in the drawing area.
		 */
		JButton btnStraightLine = new JButton("Straight Line");
		btnStraightLine.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				m_line.setVisible(true);
				m_particles.setVisible(false);
			}
		});
		btnStraightLine.setBounds(213, 18, 117, 29);
		frame.getContentPane().add(btnStraightLine);

		/**
		 * The JPanel which is the "drawing area" for the user to draw in.
		 */
		m_panel = new JPanel();
		m_particles = new DrawElement();
		m_panel.add(m_particles);
		m_particles.setVisible(false);

		m_line = new StraightLine();
		m_panel.add(m_line);
		m_line.setVisible(false);

		/**
		 * Below is the layout of the JFrame which holds the buttons and JPanel
		 * described above.
		 * 
		 */
		GroupLayout gl_particles = new GroupLayout(m_particles);
		gl_particles.setHorizontalGroup(gl_particles.createParallelGroup(Alignment.LEADING).addGap(0, 10,
				Short.MAX_VALUE));
		gl_particles.setVerticalGroup(gl_particles.createParallelGroup(Alignment.LEADING)
				.addGap(0, 10, Short.MAX_VALUE));
		m_particles.setLayout(gl_particles);
		m_panel.setBackground(Color.WHITE);
		m_panel.setBounds(6, 50, 438, 200);
		frame.getContentPane().add(m_panel);
		GroupLayout gl_panel = new GroupLayout(m_panel);
		gl_panel.setHorizontalGroup(gl_panel
				.createParallelGroup(Alignment.LEADING)
				.addGroup(
						gl_panel.createSequentialGroup().addGap(10)
								.addComponent(m_particles, GroupLayout.PREFERRED_SIZE, 438, GroupLayout.PREFERRED_SIZE))
				.addGroup(
						gl_panel.createSequentialGroup()
								.addComponent(m_line, GroupLayout.DEFAULT_SIZE, 438, Short.MAX_VALUE).addContainerGap()));
		gl_panel.setVerticalGroup(gl_panel.createParallelGroup(Alignment.LEADING).addGroup(
				gl_panel.createSequentialGroup()
						.addComponent(m_line, GroupLayout.PREFERRED_SIZE, 197, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(ComponentPlacement.RELATED)
						.addComponent(m_particles, GroupLayout.PREFERRED_SIZE, 195, GroupLayout.PREFERRED_SIZE)));
		m_panel.setLayout(gl_panel);
	}

	public void actionPerformed(ActionEvent e) {
		Color initialcolor = Color.BLACK;
		Color color = JColorChooser.showDialog(this, "Select a color", initialcolor);
		m_c.setBackground(color);
	}

	DrawElement m_particles;
	StraightLine m_line;
	Container m_c;
	BufferedImage m_CurrentImage;
	JPanel m_panel;
}
