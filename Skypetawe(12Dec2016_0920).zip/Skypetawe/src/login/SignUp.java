package login;

import java.util.Date;

import java.util.Scanner;

import filereader.AccountReader;
import login.Account;
/**
 * Signup lets a user add an account to the database
 * @Author Tim Brook
 * @Version 1.2
 */
public class SignUp {


	public Scanner in = new Scanner(System.in);

	/**
	 * Checks whether a username already exists, if so asks them to choose a different name 
	 * otherwise creates the account
	 * @param username, the name they have chosen
	 */
	public void validateSignup(String username, String password, String firstName, String lastName, String ukPhoneNo) throws Exception{
		Account acc = new Account(username, password, firstName, lastName, ukPhoneNo);
		
		try {
			new AccountReader().write(acc);
		}catch(Exception e) {
			throw e;
		}
		/*
		if(username.compareTo(Account.getUsername(username))) {
			System.out.println("Please choose a diiferent username, the one you have chosen is taken");
			
		}
		else {
				Account acc = new Account(username, password, firstName, lastName, ukPhoneNo);
		}*/
	}
}

