/**
 * DrawElement.java
 * @author Rhydian Morgan
 */

package draw;

import java.awt.Color;

import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseListener;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class DrawElement extends JPanel {

	/**
	 * 
	 * @return the current number of points
	 */
	public int getPointCount() {
		return m_PointCount;
	}

	/**
	 * 
	 * @return the point counter
	 */
	public int increasePointCount() {
		m_PointCount++;
		return m_PointCount;
	}

	/**
	 * 
	 * @return the current number of points
	 */
	public Point[] getPoints() {
		return m_Points;
	}

	/**
	 * 
	 * @param point The current point of the mouse event
	 * @return true to show success
	 */
	public boolean setPoint(Point point) {
		m_Points[getPointCount()] = point;
		return true;
	}

	/**
	 * Constructor
	 * Makes a new instance of DrawElement
	 */
	public DrawElement() {

		PaintHandler handler = new PaintHandler();
		this.addMouseListener(handler);
		this.addMouseMotionListener(handler);
	}

	/**
	 * Overrides paintComponent to draw the rectangles to the screen
	 * @param g An instance of Graphics
	 */
	public void paintComponent(Graphics g) {

		g.setColor(Color.black);
		super.paintComponent(g);

		for (int i = 0; i < this.getPointCount(); i++) {

			g.fillRect(getPoints()[i].x, getPoints()[i].y, RECT_WIDTH, RECT_HEIGHT);
		}
	}

	private class PaintHandler implements MouseListener, MouseMotionListener {
		
		/**
		 * When mouse is dragged increases the point counter
		 * and then sets the current point to the event point
		 * and repaints the window
		 * @param event is a Mouse Event
		 */
		public void mouseDragged(MouseEvent event) {

			if (getPointCount() < getPoints().length) {

				setPoint(event.getPoint());

				increasePointCount();

				repaint();

			}
		}

		/**
		 * Registers the mouse moving
		 * @param event is a Mouse Event
		 */
		public void mouseMoved(MouseEvent event) {
		}

		/**
		 * Registers the mouse leaving the window area
		 * @param event is a Mouse Event
		 */
		public void mouseExited(MouseEvent event) {
		}
		
		/**
		 * Registers the mouse clicking
		 * @param event is a Mouse Event
		 */
		public void mouseClicked(MouseEvent event) {
		}

		/**
		 * Registers the mouse pressing
		 * @param event is a Mouse Event
		 */
		public void mousePressed(MouseEvent event) {
		}

		/**
		 * Registers the mouse being released
		 * @param event is a Mouse Event
		 */
		public void mouseReleased(MouseEvent event) {
		}

		/**
		 * Registers the mouse entering the window
		 * @param event is a Mouse Event
		 */
		public void mouseEntered(MouseEvent event) {
		}

	}

	protected Color black = Color.black;
	protected int m_Thickness;
	protected Color m_Colour;
	public final static int FRAME_WIDTH = 500;
	public final static int FRAME_HEIGHT = 500;
	private int m_PointCount = 0;
	private final int RECT_WIDTH = 5;
	private final int RECT_HEIGHT = 5;
	private final int MAX_POINTS = 100000;
	private Point m_Points[] = new Point[MAX_POINTS];

}
