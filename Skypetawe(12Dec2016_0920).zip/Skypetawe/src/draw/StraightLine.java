/**
 * StraightLine.java

 * @author Rhydian Morgan and Sevan Boyrazian
 */

package draw;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class StraightLine extends JPanel {
	
	/**
	 * For testing purposes
	 */
	/* 
	public static void main(String args[]) {
		StraightLine line = new StraightLine();
		JFrame cde = new JFrame("Draw a Red Line");
		cde.add(line, BorderLayout.CENTER);
		cde.setSize(300, 300);
		cde.setLocation(300, 300);
		cde.setResizable(false);
		cde.setVisible(true);
		
	}*/
	
	/**
	 * Constructor
	 * Makes a new instance of StraightLine
	 */
	public StraightLine() {
		PaintHandler handler = new PaintHandler();
		this.addMouseListener(handler);
		this.addMouseMotionListener(handler);
	}
	
	
	/**
	 * Creates a new instance of straight Line
	 */
	private static void createAndShowStraightLineGUI(){
		StraightLine line = new StraightLine();
		//For testing purposes
		/*
		JFrame cde = new JFrame("Draw a Line");
		cde.add(line, BorderLayout.CENTER);
		cde.setSize(300, 300);
		cde.setLocation(300, 300);
		cde.setResizable(false);
		cde.setVisible(true);
		//Display the window.
        cde.pack();
        cde.setVisible(true);*/
	}
	
	/**
	 * Runs the instance of straight line from the createAndShowStraightLineGUI
	 */
	public static void LoadStraightLine(){
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run(){
				createAndShowStraightLineGUI();
			}		
	});
}

	/**
	 * Overrides the paintComponent method to draw the straight lines to the screen
	 * @param g An instance of Graphics
	 */
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.setColor(m_selectedColor);
		for(int i = 0; i < m_StartPoints.size(); i++){
			Point startPoints = m_StartPoints.get(i);
			Point endPoints = m_EndPoints.get(i);
			g.drawLine(startPoints.x, startPoints.y, endPoints.x, endPoints.y);
		}
		
	}
	private class PaintHandler implements MouseListener, MouseMotionListener {

		/**
		 * Registers the mouse pressing
		 * @param e is a Mouse Event
		 */
		public void mousePressed(MouseEvent e) {
		}

		/**
		 * Registers the mouse moving
		 * @param e is a Mouse Event
		 */
		public void mouseMoved(MouseEvent e) {
		}

		/**
		 * Registers when the mouse is dragged
		 * @param e is a Mouse Event
		 */
		public void mouseDragged(MouseEvent e) {
		}
		
		/**
		 * Registers the mouse being released
		 * @param e is a Mouse Event
		 */
		public void mouseReleased(MouseEvent e) {
		}

		/**
		 * If the two array lists are the same length the mouse event
		 * point is saved into start points array, and if they're
		 * different it gets stored into the end points array and then
		 * repaints the window
		 * @param e is a Mouse Event
		 */
		public void mouseClicked(MouseEvent e) {
			
			if (m_StartPoints.size() == m_EndPoints.size()){
				m_StartPoints.add(e.getPoint());
			}else {
				m_currPoint  = e.getPoint();
				m_EndPoints.add(m_currPoint);
				
			}
			repaint();
			
		}

		/**
		 * Registers the mouse entering the window
		 * @param e is a Mouse Event
		 */
		public void mouseEntered(MouseEvent e) {	
		}

		/**
		 * Registers the mouse leaving the window area
		 * @param e is a Mouse Event
		 */
		public void mouseExited(MouseEvent e) {	
		}
	}

	private Color m_selectedColor = Color.BLACK;
	private Point m_currPoint;
	private List<Point> m_StartPoints = new ArrayList<Point>();
	private List<Point> m_EndPoints = new ArrayList<Point>();
}
