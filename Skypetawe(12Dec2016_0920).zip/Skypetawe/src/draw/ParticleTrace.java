/**
 * ParticleTrace.java

 * @author Rhydian Morgan and Sevan Boyrazian
 */

package draw;


import javax.swing.JFrame;

import java.awt.BorderLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JMenuBar;


public class ParticleTrace extends DrawElement{
	
	/**
	 * Main method for testing the particle trace.
	 */
	/*public static void main(String [] args){
		JFrame cde = new JFrame ("Creative Drawing Environment");
		DrawElement particles = new DrawElement();
		cde.getContentPane().add(particles, BorderLayout.CENTER);
		cde.setVisible(true);
		cde.setSize(MAX_WIDTH, MAX_HEIGHT);
		cde.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}*/
	
	
	/**
	 * Creates new instance of drawing Particles
	 */
	private static void createAndShowParticleGUI(){
		DrawElement particles = new DrawElement();
	}
	
	/**
	 * Runs the instance of particles from the 'createAndShowParticleGUI' method.
	 */
	public static void LoadParticles(){
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run(){
				createAndShowParticleGUI();
			}
		});
	}
	
	/**
	 * Height and width of window for testing purposes in the main method above.
	 */
	/*
	static final int MAX_HEIGHT = 500;
	static final int MAX_WIDTH = 500;*/
}
